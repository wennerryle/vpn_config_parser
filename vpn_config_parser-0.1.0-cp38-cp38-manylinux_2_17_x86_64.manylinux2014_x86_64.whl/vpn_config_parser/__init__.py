from .vpn_config_parser import *

__doc__ = vpn_config_parser.__doc__
if hasattr(vpn_config_parser, "__all__"):
    __all__ = vpn_config_parser.__all__